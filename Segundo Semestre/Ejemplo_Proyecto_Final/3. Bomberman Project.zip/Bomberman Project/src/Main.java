import presentation.Game;

public class Main{

    public static void main(String[] args) {
        Game bomberman = new Game("Bomberman", 608, 480);
        bomberman.start();
    }
}

