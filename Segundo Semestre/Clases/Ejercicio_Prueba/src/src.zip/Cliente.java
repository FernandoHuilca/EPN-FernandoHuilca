public class Cliente {
    private String nombreCliente;

    public Cliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String nombre() {
        return nombreCliente;
    }
}
