public class Alimento extends ProductoDeVenta {
    public Alimento(double precio, String nombre) {
        super(precio,nombre);
    }
}
