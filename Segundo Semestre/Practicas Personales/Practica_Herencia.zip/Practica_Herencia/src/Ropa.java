public class Ropa extends ProductoDeVenta {
    public Ropa(double precio, String nombre) {
        super(precio,nombre);
    }
}
