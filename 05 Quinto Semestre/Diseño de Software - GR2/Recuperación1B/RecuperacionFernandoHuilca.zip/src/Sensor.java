interface Sensor {
    void actualizar(Double cantidadLuminosidad);
}
