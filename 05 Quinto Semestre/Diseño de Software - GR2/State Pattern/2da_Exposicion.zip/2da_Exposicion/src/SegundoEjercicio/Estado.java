package SegundoEjercicio;

public interface Estado {
    void insertarCuarto();
    void expulsarCuarto();
    void girarManivela();
    void dispensar();
}
