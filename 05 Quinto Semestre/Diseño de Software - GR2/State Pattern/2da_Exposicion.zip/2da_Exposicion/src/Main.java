
// Author: Fernando Huilca by Head First Design Patterns

public class Main {
    public static void main(String[] args) {
        PrimerEjercicio.MaquinaDeChicles maquinaDeChicles = new PrimerEjercicio.MaquinaDeChicles(3);
        SegundoEjercicio.MaquinaDeChicles maquinaDeChicles2 = new SegundoEjercicio.MaquinaDeChicles(40);
        Propuesta.MaquinaDeChicles maquinaDeChicles3 = new Propuesta.MaquinaDeChicles(15);











        /*
        maquinaDeChicles.insertarCuarto();
        maquinaDeChicles.girarManivela();



        maquinaDeChicles2.insertarCuarto();
        maquinaDeChicles2.girarManivela();
        maquinaDeChicles2.insertarCuarto();
        maquinaDeChicles2.girarManivela();
        maquinaDeChicles2.insertarCuarto();
        maquinaDeChicles2.girarManivela();
        maquinaDeChicles2.insertarCuarto();
        maquinaDeChicles2.girarManivela();




        maquinaDeChicles3.insertarCuarto();
        maquinaDeChicles3.girarManivela();

        maquinaDeChicles3.insertarCuarto();
        maquinaDeChicles3.girarManivela();

        maquinaDeChicles3.insertarCuarto();
        maquinaDeChicles3.girarManivela();

        maquinaDeChicles3.insertarCuarto();
        maquinaDeChicles3.girarManivela();

        maquinaDeChicles3.insertarCuarto();
        maquinaDeChicles3.girarManivela();

        maquinaDeChicles3.insertarCuarto();
        maquinaDeChicles3.girarManivela();
        */


    }
}














